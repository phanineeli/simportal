package com.Simportal.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Simportal.Entity.CusotmerIdentityEntity;

public interface CustomerIdentityRepo extends JpaRepository<CusotmerIdentityEntity,Long>{

}
