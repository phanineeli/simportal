package com.Simportal.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Simportal.Entity.SimOffersEntitity;

public interface SimOffersRepo extends JpaRepository<SimOffersEntitity,Integer> {

}
