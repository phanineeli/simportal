package com.Simportal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SimportalApplicationTests {

	@Test
	void contextLoads() {
	}

}
